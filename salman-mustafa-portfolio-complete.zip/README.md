# Salman Mustafa — Portfolio

A responsive personal portfolio with a lavender and purple theme.

## Open locally
1. Extract this ZIP file first.
2. Open `index.html` in your browser.
3. The theme is embedded in `index.html`, so the colors and layout will still work even if you only preview that file.

## Publish with GitHub Pages
1. Create a repository, for example `salman-mustafa-portfolio`.
2. Extract this ZIP file on your computer.
3. Upload `index.html`, `script.js`, and this `README.md` to the **root** of the repository (not inside an extra nested folder).
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select `main` and `/(root)`, then save.
7. GitHub will show your published website link in Pages settings.

## Contact details shown publicly
- Email: smjunjua07@gmail.com
- GitHub: https://github.com/SALMAN-JANJUA
- Mobile: 03067080115

Privacy note: The mobile number is publicly visible. Remove its contact link from `index.html` if you do not want to publish it.
